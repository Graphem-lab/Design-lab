#pragma once

void startWebServer(bool setupMode);
void handleWebServer();