#pragma once

#define DATA_PIN 6   //43
#define NUM_LEDS 117

#define WIDTH 11
#define HEIGHT 10

#define MIN1 110
#define MIN2 112
#define MIN3 114
#define MIN4 116

#define DEFAULT_BRIGHTNESS 120

#define AP_SSID "Wordclock-Setup-Emel"  //Für jeden Schüler ändern
#define AP_PASS "12345678"