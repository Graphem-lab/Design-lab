#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <time.h>
#include <FastLED.h>
#include <ESPmDNS.h>

#include "config.h"
#include "matrix.h"
#include "web.h"

CRGB leds[NUM_LEDS];
CRGB clockColor = CRGB::White;

Preferences prefs;

int globalBrightness = DEFAULT_BRIGHTNESS;

bool setupMode = false;
bool forceClockRedraw = false;

bool fadeEnabled = false;
int fadeSpeed = 50;
uint8_t fadeHue = 0;
unsigned long lastFadeUpdate = 0;

bool nightModeEnabled = false;
int nightStartHour = 22;
int nightStartMinute = 0;
int nightEndHour = 7;
int nightEndMinute = 0;

unsigned long lastClockUpdate = 0;
unsigned long lastSetupBlink = 0;
bool setupBlinkState = false;

// =====================================================
// BASIS
// =====================================================

void clearAll() {
  fill_solid(leds, NUM_LEDS, CRGB::Black);
}

// =====================================================
// NACHTMODUS
// =====================================================

bool isNightModeActive() {
  if (!nightModeEnabled) return false;

  struct tm t;
  if (!getLocalTime(&t)) return false;

  int nowMin = t.tm_hour * 60 + t.tm_min;
  int startMin = nightStartHour * 60 + nightStartMinute;
  int endMin = nightEndHour * 60 + nightEndMinute;

  if (startMin == endMin) return false;

  if (startMin < endMin) {
    return nowMin >= startMin && nowMin < endMin;
  } else {
    return nowMin >= startMin || nowMin < endMin;
  }
}

void applyEffectiveBrightness() {
  if (isNightModeActive()) {
    FastLED.setBrightness(20);
  } else {
    FastLED.setBrightness(globalBrightness);
  }
}

// =====================================================
// LED STARTTEST
// =====================================================

void runLedSnakeTest() {
  clearAll();
  FastLED.show();

  const int tailLength = 8;

  for (int head = 0; head < NUM_LEDS + tailLength; head++) {
    clearAll();

    for (int t = 0; t < tailLength; t++) {
      int idx = head - t;

      if (idx >= 0 && idx < NUM_LEDS) {
        uint8_t b = 255 - (t * 28);
        leds[idx] = CRGB(b, b, b);
      }
    }

    FastLED.show();
    delay(25);
  }

  clearAll();
  FastLED.show();
}

// =====================================================
// ROTER LADEKREIS
// =====================================================

const int spinnerCount = 18;

int spinner[spinnerCount][2] = {
  {4,0},{5,0},{6,0},
  {8,1},{9,2},
  {10,4},{10,5},
  {9,7},{8,8},
  {6,9},{5,9},{4,9},
  {2,8},{1,7},
  {0,5},{0,4},
  {1,2},{2,1}
};

void drawLoadingCircle(int step, CRGB color) {
  clearAll();

  const int tail = 5;

  for (int i = 0; i < tail; i++) {
    int idx = (step - i + spinnerCount) % spinnerCount;
    uint8_t fade = 255 - (i * 45);

    CRGB c = color;
    c.nscale8(fade);

    leds[getIndex(spinner[idx][0], spinner[idx][1])] = c;
  }

  FastLED.show();
}

// =====================================================
// GELBER KREIS
// =====================================================

void drawCircle(CRGB color) {
  clearAll();

  int p[][2] = {
    {4,0},{5,0},{6,0},
    {2,1},{8,1},
    {1,2},{9,2},
    {0,4},{10,4},
    {0,5},{10,5},
    {1,7},{9,7},
    {2,8},{8,8},
    {4,9},{5,9},{6,9}
  };

  int count = sizeof(p) / sizeof(p[0]);

  for (int i = 0; i < count; i++) {
    leds[getIndex(p[i][0], p[i][1])] = color;
  }

  FastLED.show();
}

// =====================================================
// HAKEN
// =====================================================

void drawCheck(CRGB color) {
  clearAll();

  int p[][2] = {
    {1,5},
    {2,6},
    {3,7},
    {4,8},
    {5,7},
    {6,6},
    {7,5},
    {8,4},
    {9,3},
    {10,2}
  };

  int count = sizeof(p) / sizeof(p[0]);

  for (int i = 0; i < count; i++) {
    leds[getIndex(p[i][0], p[i][1])] = color;
  }

  FastLED.show();
}

// =====================================================
// WLAN
// =====================================================

bool connectSavedWiFi() {
  String ssid = prefs.getString("ssid", "");
  String pass = prefs.getString("pass", "");

  ssid.trim();
  pass.trim();

  if (ssid.length() == 0) {
    Serial.println("Keine WLAN Daten.");
    return false;
  }

  Serial.print("Verbinde mit: ");
  Serial.println(ssid);

  WiFi.disconnect(true);
  delay(1000);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), pass.c_str());

  int anim = 0;

  for (int i = 0; i < 150; i++) {
    drawLoadingCircle(anim, CRGB::Red);

    anim++;
    if (anim >= spinnerCount) anim = 0;

    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("WLAN verbunden!");
      Serial.print("IP: ");
      Serial.println(WiFi.localIP());

      if (MDNS.begin("wordclock")) {
        Serial.println("mDNS gestartet");
        Serial.println("http://wordclock.local");
      }

      for (int j = 0; j < 5; j++) {
        drawCheck(CRGB::Green);
        delay(300);
        clearAll();
        FastLED.show();
        delay(300);
      }

      return true;
    }

    delay(100);
  }

  return false;
}

// =====================================================
// HOTSPOT
// =====================================================

void startSetupHotspot() {
  setupMode = true;

  WiFi.disconnect(true);
  delay(1000);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS, 1, 0, 4);

  Serial.println("Setup Hotspot gestartet");
  Serial.println(WiFi.softAPIP());

  startWebServer(true);
}

// =====================================================
// WÖRTER
// =====================================================

void showWord(const char* name, CRGB color) {
  for (int i = 0; i < wordCount; i++) {
    if (strcmp(words[i].name, name) == 0) {
      for (int l = 0; l < words[i].len; l++) {
        int idx = getIndex(words[i].x + l, words[i].y);
        leds[idx] = color;
      }
    }
  }
}

// =====================================================
// MINUTENPUNKTE
// =====================================================

void showMinutes(int m) {
  int e = m % 5;

  leds[MIN1] = CRGB::Black;
  leds[MIN2] = CRGB::Black;
  leds[MIN3] = CRGB::Black;
  leds[MIN4] = CRGB::Black;

  if (e >= 1) leds[MIN1] = clockColor;
  if (e >= 2) leds[MIN2] = clockColor;
  if (e >= 3) leds[MIN3] = clockColor;
  if (e >= 4) leds[MIN4] = clockColor;
}

// =====================================================
// STUNDENWORT
// =====================================================

void showHour(int hour) {
  switch (hour) {
    case 1:  showWord("EINS", clockColor); break;
    case 2:  showWord("ZWEI", clockColor); break;
    case 3:  showWord("DREI_H", clockColor); break;
    case 4:  showWord("VIER_H", clockColor); break;
    case 5:  showWord("FÜNF_H", clockColor); break;
    case 6:  showWord("SECHS", clockColor); break;
    case 7:  showWord("SIEBEN", clockColor); break;
    case 8:  showWord("ACHT", clockColor); break;
    case 9:  showWord("NEUN", clockColor); break;
    case 10: showWord("ZEHN_H", clockColor); break;
    case 11: showWord("ELF", clockColor); break;
    case 12: showWord("ZWÖLF", clockColor); break;
  }
}

// =====================================================
// CLOCK
// =====================================================

void updateClock() {
  struct tm t;

  if (!getLocalTime(&t)) {
    return;
  }

  int h = t.tm_hour;
  int m = t.tm_min;

  h = h % 12;
  if (h == 0) h = 12;

  int rounded = (m / 5) * 5;
  int displayHour = h;

  if (rounded >= 25) displayHour++;
  if (displayHour > 12) displayHour = 1;

  clearAll();

  showWord("ES", clockColor);
  showWord("IST", clockColor);

  switch (rounded) {
    case 0:  showWord("UHR", clockColor); break;
    case 5:  showWord("FÜNF", clockColor); showWord("NACH", clockColor); break;
    case 10: showWord("ZEHN", clockColor); showWord("NACH", clockColor); break;
    case 15: showWord("VIERTEL", clockColor); showWord("NACH", clockColor); break;
    case 20: showWord("ZWANZIG", clockColor); showWord("NACH", clockColor); break;
    case 25: showWord("FÜNF", clockColor); showWord("VOR", clockColor); showWord("HALB", clockColor); break;
    case 30: showWord("HALB", clockColor); break;
    case 35: showWord("FÜNF", clockColor); showWord("NACH", clockColor); showWord("HALB", clockColor); break;
    case 40: showWord("ZWANZIG", clockColor); showWord("VOR", clockColor); break;
    case 45: showWord("VIERTEL", clockColor); showWord("VOR", clockColor); break;
    case 50: showWord("ZEHN", clockColor); showWord("VOR", clockColor); break;
    case 55: showWord("FÜNF", clockColor); showWord("VOR", clockColor); break;
  }

  showHour(displayHour);
  showMinutes(m);

  applyEffectiveBrightness();
  FastLED.show();
}

// =====================================================
// FADING
// =====================================================

void updateFading() {
  if (!fadeEnabled) return;

  unsigned long now = millis();

  int interval = map(fadeSpeed, 1, 100, 220, 45);

  if (now - lastFadeUpdate >= (unsigned long)interval) {
    lastFadeUpdate = now;

    fadeHue++;
    clockColor = CHSV(fadeHue, 255, 255);

    forceClockRedraw = true;
  }
}

// =====================================================
// SETUP
// =====================================================

void setup() {
  Serial.begin(115200);

  prefs.begin("wordclock", false);

  globalBrightness = prefs.getInt("brightness", DEFAULT_BRIGHTNESS);

  int r = prefs.getInt("color_r", 255);
  int g = prefs.getInt("color_g", 255);
  int b = prefs.getInt("color_b", 255);

  clockColor = CRGB(r, g, b);

  fadeEnabled = prefs.getBool("fade_enabled", false);
  fadeSpeed = prefs.getInt("fade_speed", 50);

  nightModeEnabled = prefs.getBool("night_enabled", false);
  nightStartHour = prefs.getInt("night_start_h", 22);
  nightStartMinute = prefs.getInt("night_start_m", 0);
  nightEndHour = prefs.getInt("night_end_h", 7);
  nightEndMinute = prefs.getInt("night_end_m", 0);

  if (fadeSpeed < 1) fadeSpeed = 1;
  if (fadeSpeed > 100) fadeSpeed = 100;

  FastLED.addLeds<WS2812B, DATA_PIN, GRB>(leds, NUM_LEDS);
  applyEffectiveBrightness();

  clearAll();
  FastLED.show();

  runLedSnakeTest();

  bool ok = connectSavedWiFi();

  if (!ok) {
    startSetupHotspot();
  } else {
    configTime(3600, 3600, "pool.ntp.org", "time.nist.gov");
    startWebServer(false);
    forceClockRedraw = true;
  }
}

// =====================================================
// LOOP
// =====================================================

void loop() {
  handleWebServer();

  if (setupMode) {
    unsigned long now = millis();

    if (now - lastSetupBlink >= 500) {
      lastSetupBlink = now;
      setupBlinkState = !setupBlinkState;

      if (setupBlinkState) {
        drawCircle(CRGB::Yellow);
      } else {
        clearAll();
        FastLED.show();
      }
    }

    return;
  }

  if (WiFi.status() == WL_CONNECTED) {
    updateFading();

    unsigned long now = millis();

    if (forceClockRedraw || now - lastClockUpdate >= 1000) {
      forceClockRedraw = false;
      lastClockUpdate = now;
      updateClock();
    }
  }
}