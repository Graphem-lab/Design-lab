#pragma once
#include <Arduino.h>

struct Word {
  const char* name;
  int x;
  int y;
  int len;
};

extern Word words[];
extern int wordCount;

int getIndex(int x, int y);