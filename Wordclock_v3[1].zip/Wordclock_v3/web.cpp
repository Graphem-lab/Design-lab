#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <FastLED.h>

#include "config.h"

extern CRGB leds[];
extern CRGB clockColor;
extern int globalBrightness;
extern Preferences prefs;
extern bool forceClockRedraw;

extern bool fadeEnabled;
extern int fadeSpeed;

extern bool nightModeEnabled;
extern int nightStartHour;
extern int nightStartMinute;
extern int nightEndHour;
extern int nightEndMinute;

extern void applyEffectiveBrightness();

WebServer server(80);

String colorToHex(CRGB c) {
  char buf[8];
  sprintf(buf, "#%02X%02X%02X", c.r, c.g, c.b);
  return String(buf);
}

String timeValue(int h, int m) {
  char buf[6];
  sprintf(buf, "%02d:%02d", h, m);
  return String(buf);
}

bool parseTimeValue(String value, int &h, int &m) {
  if (value.length() != 5) return false;
  if (value.charAt(2) != ':') return false;

  h = value.substring(0, 2).toInt();
  m = value.substring(3, 5).toInt();

  if (h < 0 || h > 23) return false;
  if (m < 0 || m > 59) return false;

  return true;
}

String baseCss() {
  return R"rawliteral(
<style>
  * {
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
  }

  body {
    margin: 0;
    min-height: 100vh;
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", Arial, sans-serif;
    background:
      radial-gradient(circle at top, rgba(255,255,255,0.08), transparent 35%),
      radial-gradient(circle at top left, rgba(35,120,255,0.28), transparent 34%),
      radial-gradient(circle at bottom right, rgba(255,60,100,0.18), transparent 32%),
      linear-gradient(180deg, #101116 0%, #050507 100%);
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 22px;
  }

  .app {
    width: 100%;
    max-width: 430px;
  }

  .brand {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px;
    filter:
      drop-shadow(0 0 10px rgba(255,255,255,0.14))
      drop-shadow(0 0 18px rgba(70,120,255,0.18));
  }

  .logo-wrap {
    width: 78px;
    height: 78px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 26px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.13);
    box-shadow:
      0 0 22px rgba(255,255,255,0.10),
      0 0 36px rgba(40,130,255,0.18),
      0 18px 55px rgba(0,0,0,0.35);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    flex-shrink: 0;
  }

  .logo-wrap svg {
    width: 62px;
    height: 62px;
  }

  .brand-text {
    text-align: left;
    line-height: 1.02;
  }

  .brand-text .fab {
    font-size: 30px;
    font-weight: 800;
    letter-spacing: -0.5px;
    color: white;
    text-shadow: 0 0 16px rgba(255,255,255,0.22);
  }

  .brand-text .kamp {
    font-size: 18px;
    font-weight: 450;
    color: rgba(255,255,255,0.78);
    margin-top: 5px;
    letter-spacing: 0.2px;
  }

  .title {
    text-align: center;
    margin-bottom: 22px;
  }

  .title h1 {
    font-size: 34px;
    line-height: 1.1;
    margin: 0;
    font-weight: 750;
    letter-spacing: 7px;
    text-shadow: 0 0 18px rgba(255,255,255,0.25);
  }

  .card {
    background: rgba(255,255,255,0.105);
    border: 1px solid rgba(255,255,255,0.16);
    box-shadow: 0 18px 55px rgba(0,0,0,0.42);
    backdrop-filter: blur(22px);
    -webkit-backdrop-filter: blur(22px);
    border-radius: 28px;
    padding: 22px;
    margin-bottom: 16px;
  }

  .label {
    font-size: 14px;
    font-weight: 650;
    color: rgba(255,255,255,0.72);
    margin-bottom: 10px;
  }

  .value {
    font-size: 38px;
    font-weight: 760;
    letter-spacing: -1.5px;
    margin-bottom: 14px;
  }

  input[type="text"],
  input[type="password"],
  input[type="time"] {
    width: 100%;
    border: 0;
    outline: 0;
    border-radius: 18px;
    padding: 15px 16px;
    font-size: 17px;
    color: white;
    background: rgba(255,255,255,0.13);
    border: 1px solid rgba(255,255,255,0.14);
  }

  input[type="time"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
    opacity: 0.75;
  }

  input::placeholder {
    color: rgba(255,255,255,0.38);
  }

  input[type="range"] {
    width: 100%;
    appearance: none;
    height: 8px;
    border-radius: 99px;
    background: rgba(255,255,255,0.22);
    outline: none;
  }

  input[type="range"]::-webkit-slider-thumb {
    appearance: none;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: white;
    box-shadow: 0 4px 22px rgba(0,0,0,0.55);
  }

  input[type="color"] {
    width: 100%;
    height: 64px;
    border: 0;
    border-radius: 22px;
    background: transparent;
    padding: 0;
  }

  input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  input[type="color"]::-webkit-color-swatch {
    border: 0;
    border-radius: 22px;
  }

  .btn {
    width: 100%;
    border: 0;
    border-radius: 20px;
    padding: 16px;
    font-size: 17px;
    font-weight: 750;
    color: #050507;
    background: white;
    box-shadow: 0 12px 32px rgba(255,255,255,0.18);
    cursor: pointer;
  }

  .btn.secondary {
    color: white;
    background: rgba(255,255,255,0.13);
    border: 1px solid rgba(255,255,255,0.16);
    box-shadow: none;
  }

  .toggle-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
  }

  .switch {
    position: relative;
    width: 62px;
    height: 36px;
    flex-shrink: 0;
  }

  .switch input {
    display: none;
  }

  .slider-switch {
    position: absolute;
    cursor: pointer;
    inset: 0;
    background: rgba(255,255,255,0.18);
    border-radius: 99px;
    transition: 0.25s;
    border: 1px solid rgba(255,255,255,0.18);
  }

  .slider-switch:before {
    position: absolute;
    content: "";
    height: 28px;
    width: 28px;
    left: 4px;
    top: 3px;
    background: white;
    border-radius: 50%;
    transition: 0.25s;
    box-shadow: 0 4px 18px rgba(0,0,0,0.45);
  }

  .switch input:checked + .slider-switch {
    background: linear-gradient(90deg, #20d66b, #00b85c);
    box-shadow: 0 0 18px rgba(32,214,107,0.45);
  }

  .switch input:checked + .slider-switch:before {
    transform: translateX(26px);
  }

  .time-grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    gap: 10px;
    margin-top: 16px;
  }

  .time-grid > div {
    min-width: 0;
  }

  .time-grid .label {
    font-size: 13px;
  }

  .time-grid input[type="time"] {
    width: 100%;
    min-width: 0;
    max-width: 100%;
    padding: 13px 8px;
    font-size: 15px;
    text-align: center;
  }

  @media (max-width: 360px) {
    .brand {
      gap: 10px;
    }

    .logo-wrap {
      width: 68px;
      height: 68px;
      border-radius: 22px;
    }

    .logo-wrap svg {
      width: 54px;
      height: 54px;
    }

    .brand-text .fab {
      font-size: 26px;
    }

    .brand-text .kamp {
      font-size: 16px;
    }

    .title h1 {
      font-size: 29px;
      letter-spacing: 5px;
    }
  }
</style>
)rawliteral";
}

String fablabLogo() {
  return R"rawliteral(
<div class="brand">
  <div class="logo-wrap">
    <svg viewBox="0 0 82 82" xmlns="http://www.w3.org/2000/svg">
      <g transform="translate(-0.5,-76)">
        <path style="fill:#009400;fill-opacity:1" d="m 38.316163,153.14417 c -7.498374,-0.59292 -13.964023,-3.13606 -19.63296,-7.72228 -6.72328,-5.43919 -11.0929041,-13.12581 -12.4309476,-21.86733 -0.3864505,-2.5247 -0.3932676,-7.58953 -0.013487,-10.02198 0.359901,-2.30515 1.041727,-5.00782 1.7435951,-6.91139 0.5668144,-1.53728 1.9765548,-4.67178 2.1011305,-4.67178 0.03953,0 0.715362,0.42534 1.501851,0.94522 l 1.429981,0.94522 0.04742,15.28707 0.04741,15.28706 4.050966,2.3279 c 2.228032,1.28035 4.152241,2.36999 4.27602,2.42143 0.174899,0.0727 0.225054,-0.59045 0.225054,-2.97554 v -3.06906 l -0.975245,-1.35928 c -1.171003,-1.63214 -2.135792,-3.60996 -2.672301,-5.47825 -0.580658,-2.02201 -0.575884,-5.6032 0.0095,-7.14497 0.892581,-2.35075 2.706143,-3.85634 4.988708,-4.14153 4.337731,-0.54196 9.757303,3.65366 12.080643,9.35237 1.49588,3.66911 1.54974,7.74757 0.134218,10.16345 -0.599487,1.02315 -1.617311,2.02969 -2.453863,2.42666 l -0.669195,0.31756 0.0027,3.99751 c 0.0014,2.19863 0.06226,4.09098 0.135034,4.20523 0.07275,0.11425 1.691898,1.1133 3.598105,2.22009 l 3.465828,2.01237 v 1.78586 c 0,0.98223 -0.06077,1.77225 -0.135034,1.7556 -0.07427,-0.0167 -0.459112,-0.0559 -0.855204,-0.0872 z"/>
        <path style="fill:#d10000;fill-opacity:1" d="m 38.138362,110.03982 c -3.904205,-0.43183 -7.736828,-2.27226 -9.372695,-4.50075 -0.933383,-1.27152 -1.145017,-1.98262 -1.154158,-3.87796 l -0.0079,-1.63861 -2.54375,-1.482075 c -1.399063,-0.815137 -2.678973,-1.446708 -2.844244,-1.403491 -0.165272,0.04321 -1.985126,1.108552 -4.044119,2.367408 -2.058995,1.258858 -3.840388,2.325958 -3.958654,2.371348 -0.159979,0.0614 -2.204185,-1.0839 -2.975981,-1.66733 -0.04007,-0.0303 0.30389,-0.621653 0.764363,-1.314141 3.379302,-5.081997 9.087478,-9.805684 14.70217,-12.166478 6.64916,-2.795755 13.615008,-3.550248 20.504294,-2.220886 6.635953,1.28048 13.108435,4.749918 17.945723,9.619428 1.569507,1.579961 4.105837,4.751162 4.665345,5.833121 l 0.269196,0.520576 -1.491435,0.7637 -1.491436,0.76369 -2.96173,-1.71068 C 62.514398,99.355821 58.71053,97.144902 55.690306,95.383541 45.478677,89.428222 41.245002,86.979037 40.855245,86.801451 c -0.328174,-0.149525 -1.056135,0.203522 -4.704439,2.281575 -2.373906,1.35216 -4.387566,2.52612 -4.474806,2.608799 -0.08786,0.08327 0.67136,0.687201 1.702024,1.353887 l 1.860643,1.20356 1.62877,-0.245911 c 2.377458,-0.358951 5.793787,-0.273694 7.570184,0.188914 3.225497,0.839984 5.826335,2.726791 6.890942,4.999095 0.426441,0.91021 0.490821,1.27198 0.490821,2.75804 0,1.60695 -0.03736,1.77935 -0.618043,2.85034 -1.99288,3.67572 -7.442441,5.86176 -13.062977,5.24007 z"/>
        <path style="fill:#0000a2;fill-opacity:1" d="m 41.648093,151.50347 c 0.0014,-1.72163 0.0099,-1.75768 0.495122,-2.03602 1.897933,-1.08867 6.472863,-3.75674 14.807396,-8.63554 5.297761,-3.10117 9.976627,-5.83357 10.397475,-6.07202 l 0.765183,-0.43354 v -5.29588 c 0,-2.91272 -0.06077,-5.29566 -0.135027,-5.29541 -0.07427,2.6e-4 -0.601058,0.28148 -1.170652,0.62495 -0.569587,0.34346 -1.50131,0.88026 -2.070495,1.19289 -1.322521,0.72641 -1.605103,0.97917 -1.752855,1.56786 -1.067431,4.25298 -4.645339,8.5268 -8.331784,9.95233 -1.481576,0.57291 -4.020627,0.68383 -5.284947,0.23085 -2.752381,-0.98611 -4.354939,-4.17827 -4.055209,-8.07764 0.497089,-6.46698 5.345292,-12.98391 10.576617,-14.21705 2.253251,-0.53113 3.804045,-0.22986 5.468064,1.06227 l 1.026615,0.79719 2.860638,-1.47322 2.860638,-1.47323 0.0077,-5.13123 0.0077,-5.13122 1.45648,-0.77557 c 0.801064,-0.42657 1.478663,-0.75065 1.50578,-0.72018 0.228701,0.25701 1.433643,2.91555 1.958971,4.32222 1.603586,4.2939 2.165687,7.82246 2.044971,12.83727 -0.09708,4.03307 -0.370649,5.8976 -1.332817,9.08406 -2.348028,7.77614 -7.042789,14.21308 -13.652258,18.71851 -5.188823,3.53703 -10.68563,5.45024 -17.32913,6.03154 l -1.125271,0.0985 z"/>
      </g>
    </svg>
  </div>

  <div class="brand-text">
    <div class="fab">FabLab</div>
    <div class="kamp">Kamp-Lintfort</div>
  </div>
</div>
)rawliteral";
}

String setupPage() {
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>Wordclock Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
)rawliteral";

  html += baseCss();

  html += R"rawliteral(
</head>
<body>
  <div class="app">
)rawliteral";

  html += fablabLogo();

  html += R"rawliteral(
    <div class="title">
      <h1>WORDCLOCK</h1>
    </div>

    <form action="/savewifi" method="GET">
      <div class="card">
        <div class="label">WLAN Name</div>
        <input name="ssid" type="text" placeholder="SSID eingeben" autocomplete="off">
      </div>

      <div class="card">
        <div class="label">WLAN Passwort</div>
        <input name="pass" type="password" placeholder="Passwort eingeben">
      </div>

      <button class="btn" type="submit">Speichern & Neustarten</button>
    </form>
  </div>
</body>
</html>
)rawliteral";

  return html;
}

String controlPage() {
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>Wordclock Control</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
)rawliteral";

  html += baseCss();

  html += R"rawliteral(
</head>
<body>
  <div class="app">
)rawliteral";

  html += fablabLogo();

  html += R"rawliteral(
    <div class="title">
      <h1>WORDCLOCK</h1>
    </div>

    <div class="card">
      <div class="label">Helligkeit</div>
      <div class="value"><span id="bv">)rawliteral";

  html += String(globalBrightness);

  html += R"rawliteral(</span></div>

      <input
        type="range"
        min="1"
        max="255"
        value=")rawliteral";

  html += String(globalBrightness);

  html += R"rawliteral("
        oninput="brightnessChanged(this.value)"
        onchange="brightnessSave(this.value)"
      >
    </div>

    <div class="card">
      <div class="label">Farbe</div>
      <input
        type="color"
        value=")rawliteral";

  html += colorToHex(clockColor);

  html += R"rawliteral("
        onchange="setColor(this.value)"
      >
    </div>

    <div class="card">
      <div class="toggle-row">
        <div>
          <div class="label">RGB Fading</div>
        </div>

        <label class="switch">
          <input type="checkbox" id="fadeToggle" onchange="setFade(this.checked)" )rawliteral";

  if (fadeEnabled) html += "checked";

  html += R"rawliteral(>
          <span class="slider-switch"></span>
        </label>
      </div>

      <br>

      <div class="label">Fading Geschwindigkeit: <span id="fv">)rawliteral";

  html += String(fadeSpeed);

  html += R"rawliteral(</span></div>

      <input
        type="range"
        min="1"
        max="100"
        value=")rawliteral";

  html += String(fadeSpeed);

  html += R"rawliteral("
        oninput="fadeSpeedChanged(this.value)"
        onchange="fadeSpeedSave(this.value)"
      >
    </div>

    <div class="card">
      <div class="toggle-row">
        <div>
          <div class="label">Nachtmodus</div>
        </div>

        <label class="switch">
          <input type="checkbox" id="nightToggle" onchange="setNight(this.checked)" )rawliteral";

  if (nightModeEnabled) html += "checked";

  html += R"rawliteral(>
          <span class="slider-switch"></span>
        </label>
      </div>

      <div class="time-grid">
        <div>
          <div class="label">Start</div>
          <input type="time" id="nightStart" value=")rawliteral";

  html += timeValue(nightStartHour, nightStartMinute);

  html += R"rawliteral(" onchange="setNightTime()">
        </div>

        <div>
          <div class="label">Ende</div>
          <input type="time" id="nightEnd" value=")rawliteral";

  html += timeValue(nightEndHour, nightEndMinute);

  html += R"rawliteral(" onchange="setNightTime()">
        </div>
      </div>
    </div>

    <div class="card">
      <button class="btn secondary" onclick="resetWiFi()">WLAN neu konfigurieren</button>
      <br><br>
      <button class="btn secondary" onclick="restart()">ESP Neustarten</button>
    </div>
  </div>

<script>
let lastBrightnessSend = 0;
let brightnessTimer = null;
let fadeSpeedTimer = null;
let lastFadeSpeedSend = 0;

function brightnessChanged(v) {
  document.getElementById("bv").innerText = v;

  const now = Date.now();

  if (now - lastBrightnessSend > 120) {
    lastBrightnessSend = now;
    fetch("/brightness?v=" + encodeURIComponent(v) + "&save=0");
  }

  clearTimeout(brightnessTimer);

  brightnessTimer = setTimeout(() => {
    fetch("/brightness?v=" + encodeURIComponent(v) + "&save=1");
  }, 500);
}

function brightnessSave(v) {
  fetch("/brightness?v=" + encodeURIComponent(v) + "&save=1");
}

function setColor(v) {
  const fadeToggle = document.getElementById("fadeToggle");
  if (fadeToggle) {
    fadeToggle.checked = false;
  }

  fetch("/color?v=" + encodeURIComponent(v));
}

function setFade(on) {
  fetch("/fade?enabled=" + (on ? "1" : "0"));
}

function fadeSpeedChanged(v) {
  document.getElementById("fv").innerText = v;

  const now = Date.now();

  if (now - lastFadeSpeedSend > 160) {
    lastFadeSpeedSend = now;
    fetch("/fadespeed?v=" + encodeURIComponent(v) + "&save=0");
  }

  clearTimeout(fadeSpeedTimer);

  fadeSpeedTimer = setTimeout(() => {
    fetch("/fadespeed?v=" + encodeURIComponent(v) + "&save=1");
  }, 600);
}

function fadeSpeedSave(v) {
  fetch("/fadespeed?v=" + encodeURIComponent(v) + "&save=1");
}

function setNight(on) {
  fetch("/night?enabled=" + (on ? "1" : "0"));
}

function setNightTime() {
  let s = document.getElementById("nightStart").value;
  let e = document.getElementById("nightEnd").value;

  fetch(
    "/nighttime?start=" + encodeURIComponent(s) +
    "&end=" + encodeURIComponent(e)
  );
}

function restart() {
  fetch("/restart");
}

function resetWiFi() {
  fetch("/resetwifi");
}
</script>

</body>
</html>
)rawliteral";

  return html;
}

void handleRootSetup() {
  server.send(200, "text/html", setupPage());
}

void handleRootControl() {
  server.send(200, "text/html", controlPage());
}

void handleSaveWiFi() {
  if (server.hasArg("ssid")) {
    String newSsid = server.arg("ssid");
    String newPass = server.arg("pass");

    newSsid.trim();
    newPass.trim();

    prefs.putString("ssid", newSsid);
    prefs.putString("pass", newPass);

    server.send(200, "text/html",
      "<html><body style='font-family:Arial;text-align:center;background:#111;color:white;'>"
      "<h2>Gespeichert</h2>"
      "<p>ESP32 startet neu...</p>"
      "</body></html>"
    );

    delay(2000);
    ESP.restart();
  } else {
    server.send(400, "text/plain", "SSID fehlt");
  }
}

void handleBrightness() {
  if (server.hasArg("v")) {
    globalBrightness = server.arg("v").toInt();

    if (globalBrightness < 1) globalBrightness = 1;
    if (globalBrightness > 255) globalBrightness = 255;

    applyEffectiveBrightness();
    forceClockRedraw = true;

    bool shouldSave = true;

    if (server.hasArg("save")) {
      shouldSave = server.arg("save") == "1";
    }

    if (shouldSave) {
      prefs.putInt("brightness", globalBrightness);
    }
  }

  server.send(200, "text/plain", "ok");
}

void handleColor() {
  if (server.hasArg("v")) {
    String c = server.arg("v");

    if (c.length() == 7 && c.charAt(0) == '#') {
      long n = strtol(c.c_str() + 1, NULL, 16);

      int r = (n >> 16) & 0xFF;
      int g = (n >> 8) & 0xFF;
      int b = n & 0xFF;

      clockColor = CRGB(r, g, b);

      prefs.putInt("color_r", r);
      prefs.putInt("color_g", g);
      prefs.putInt("color_b", b);

      fadeEnabled = false;
      prefs.putBool("fade_enabled", false);

      forceClockRedraw = true;
    }
  }

  server.send(200, "text/plain", "ok");
}

void handleFade() {
  if (server.hasArg("enabled")) {
    fadeEnabled = server.arg("enabled") == "1";
    prefs.putBool("fade_enabled", fadeEnabled);
    forceClockRedraw = true;
  }

  server.send(200, "text/plain", "ok");
}

void handleFadeSpeed() {
  if (server.hasArg("v")) {
    fadeSpeed = server.arg("v").toInt();

    if (fadeSpeed < 1) fadeSpeed = 1;
    if (fadeSpeed > 100) fadeSpeed = 100;

    bool shouldSave = true;

    if (server.hasArg("save")) {
      shouldSave = server.arg("save") == "1";
    }

    if (shouldSave) {
      prefs.putInt("fade_speed", fadeSpeed);
    }
  }

  server.send(200, "text/plain", "ok");
}

void handleNight() {
  if (server.hasArg("enabled")) {
    nightModeEnabled = server.arg("enabled") == "1";
    prefs.putBool("night_enabled", nightModeEnabled);

    applyEffectiveBrightness();
    forceClockRedraw = true;
  }

  server.send(200, "text/plain", "ok");
}

void handleNightTime() {
  if (server.hasArg("start") && server.hasArg("end")) {
    int sh, sm, eh, em;

    if (parseTimeValue(server.arg("start"), sh, sm) &&
        parseTimeValue(server.arg("end"), eh, em)) {
      nightStartHour = sh;
      nightStartMinute = sm;
      nightEndHour = eh;
      nightEndMinute = em;

      prefs.putInt("night_start_h", nightStartHour);
      prefs.putInt("night_start_m", nightStartMinute);
      prefs.putInt("night_end_h", nightEndHour);
      prefs.putInt("night_end_m", nightEndMinute);

      applyEffectiveBrightness();
      forceClockRedraw = true;
    }
  }

  server.send(200, "text/plain", "ok");
}

void handleRestart() {
  server.send(200, "text/plain", "restart");
  delay(500);
  ESP.restart();
}

void handleResetWiFi() {
  prefs.remove("ssid");
  prefs.remove("pass");

  server.send(200, "text/html",
    "<html><body style='font-family:Arial;text-align:center;background:#111;color:white;'>"
    "<h2>WLAN gelöscht</h2>"
    "<p>ESP32 startet im Setup-Modus neu...</p>"
    "</body></html>"
  );

  delay(2000);
  ESP.restart();
}

void startWebServer(bool setupMode) {
  server.stop();

  if (setupMode) {
    server.on("/", handleRootSetup);
    server.on("/savewifi", handleSaveWiFi);
  } else {
    server.on("/", handleRootControl);
    server.on("/brightness", handleBrightness);
    server.on("/color", handleColor);
    server.on("/fade", handleFade);
    server.on("/fadespeed", handleFadeSpeed);
    server.on("/night", handleNight);
    server.on("/nighttime", handleNightTime);
    server.on("/restart", handleRestart);
    server.on("/resetwifi", handleResetWiFi);
  }

  server.begin();
}

void handleWebServer() {
  server.handleClient();
}