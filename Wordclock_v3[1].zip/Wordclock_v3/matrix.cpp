#include <Arduino.h>
#include "matrix.h"
#include "config.h"

int getIndex(int x, int y) {
  if (y % 2 == 0) {
    return y * WIDTH + x;
  } else {
    return y * WIDTH + (WIDTH - 1 - x);
  }
}

/*
  Echtes Layout deiner Frontplatte:

  y0: E S R I S T A F Ü N F
  y1: Z E H N Z W A N Z I G
  y2: D R E I V I E R T E L
  y3: B V O R U N N A C H Z
  y4: H A L B A E L F Ü N F
  y5: E I N S X Z W E I P I
  y6: Q D R E I U J V I E R
  y7: S E C H S N L A C H T
  y8: S I E B E N Z W Ö L F
  y9: Z E H N E U N O U H R
*/

Word words[] = {
  // Grundtext
  {"ES",       0, 0, 2},
  {"IST",      3, 0, 3},

  // Minutenwörter
  {"FÜNF",     7, 0, 4},
  {"ZEHN",     0, 1, 4},
  {"ZWANZIG",  4, 1, 7},
  {"VIERTEL",  4, 2, 7},
  {"VOR",      1, 3, 3},
  {"NACH",     6, 3, 4},
  {"HALB",     0, 4, 4},

  // Stunden
  {"EINS",     0, 5, 4},
  {"ZWEI",     5, 5, 4},
  {"DREI_H",   1, 6, 4},
  {"VIER_H",   7, 6, 4},
  {"FÜNF_H",   7, 4, 4},
  {"SECHS",    0, 7, 5},
  {"ACHT",     7, 7, 4},
  {"SIEBEN",   0, 8, 6},
  {"ZWÖLF",    6, 8, 5},
  {"ZEHN_H",   0, 9, 4},
  {"NEUN",     3, 9, 4},
  {"ELF",      5, 4, 3},

  // Uhr
  {"UHR",      8, 9, 3}
};

int wordCount = sizeof(words) / sizeof(Word);